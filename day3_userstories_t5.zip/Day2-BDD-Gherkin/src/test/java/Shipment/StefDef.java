package Shipment;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StefDef {
	
	@Given("^Shipment Page$")
	public void shipment_Page() throws Throwable {
	  
	}

	@Given("^AddressId$")
	public void addressid() throws Throwable {
	  
	}

	@Given("^ProductId$")
	public void productid() throws Throwable {
	   
	}

	@When("^clicks on submit button$")
	public void clicks_on_submit_button() throws Throwable {
	   
	}

	@Then("^navigate to next page$")
	public void navigate_to_next_page() throws Throwable {
	   
	}



}
